/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan3;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Pertemuan3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String kondisi;
        kondisi = JOptionPane.showInputDialog(null, "silahkan pilih kondisi [biodata atau kalkulator]");
        Pertemuan3 per = new Pertemuan3();
  if(kondisi.equals("biodata")){
      per.biodata();
  }else if(kondisi.equals("kalkulator")){
      per.kalkulator();
  }      
    }
    void biodata(){
        JOptionPane.showMessageDialog(null, "void biodata");
        // variable
    String nama_depan,
            nama_belakang,
            tempat,
            tgl_lahir,
            alamat,
            grade,
            matkul;
    int nohp, nilai;
    
    //input dengan joptionpane
    nama_depan = JOptionPane.showInputDialog(null, "masukan Nama Depan Anda : ");
    nama_belakang = JOptionPane.showInputDialog(null, "masukan Nama Belakang Anda");
    tempat = JOptionPane.showInputDialog(null, "Masukan Tempat Lahir Anda : ");
    tgl_lahir = JOptionPane.showInputDialog(null, "Masukan tanggal lahir Anda");
    nohp = Integer.parseInt(JOptionPane.showInputDialog("masukan No HP anda :"));
    matkul = JOptionPane.showInputDialog(null, "masukan mata kuliah Anda : ");
    nilai = Integer.parseInt(JOptionPane.showInputDialog(null, "masukan nilai Anda :"));
    alamat = JOptionPane.showInputDialog(null, "Masukan Alamat Anda :");
    if (nilai > 90 && nilai <= 100){
          grade = "A";
      } else if (nilai > 80 && nilai <= 90){
          grade = "B+";
      } else if (nilai > 70 && nilai <= 80){
          grade = "B";
      }else if (nilai > 60 && nilai <= 70){
          grade = "C+";
      }else if (nilai > 50 && nilai <= 60){
          grade = "C";
      }else if (nilai > 40 && nilai <= 50){
          grade = "D";
      } else {
          grade = "E";
      }
     
    //output popup
    JOptionPane.showMessageDialog(null, "=========Biodata======\n" +
            "Nama : " + nama_depan + "" + nama_belakang + "\n" +
            "tempat/tanggal lahir : " + tempat + "" + tgl_lahir + "\n" +
                    "No Hp : " + nohp + "\n" +
                    "Nama Matakuliah saat ini : " + matkul + "\n" +
                    "Nilai Angka : " + nilai + "\n" +
                    "Nilai Huruf : " + grade + "\n" +
                    "Alamat : " + alamat
            );
    }
    void kalkulator(){
     JOptionPane.showMessageDialog(null, "void kalkulator");
     //variable
     String nilaipertama, nilaikedua;
     int nilai1, nilai2, tambah, kurang, kali, bagi;
     //input
     nilaipertama = JOptionPane.showInputDialog(null, "Masukan bilangan 1 (harus Angka) :");
     nilaikedua   = JOptionPane.showInputDialog(null, "Masukan Bilangan 2 (Harus Angka) :");
     
     nilai1 = Integer.parseInt(nilaipertama);
     nilai2 = Integer.parseInt(nilaikedua);
     
     tambah = nilai1 + nilai2;
     kurang = nilai1 - nilai2;
     kali   = nilai1 * nilai2;
     bagi   = nilai1 / nilai2;
     
     // ouput 
     JOptionPane.showMessageDialog(null,
      "Bilangan pertama : " + nilai1 + "\n" +
      "Bilangin kedua   : " + nilai2 + "\n" +
      "Tambah           : " + nilai1 + " + " + nilai2 + "Adalah" + tambah + "\n" +
      "Kurang           : " +  nilai1 + " - " + nilai2 + "Adalah" + kurang + "\n" +
      "Kali             : " + nilai1 + " * " + nilai2 + "Adalah" + kali + "\n" +
      "Bagi             : " + nilai1 + " / " + nilai2 + "Adalah" + bagi + "\n" );
     
    }
    
}
